package com.buct.acmer.service;

import com.buct.acmer.entity.Student;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author BUCT
 * @since 2022-06-14
 */
public interface IStudentService extends IService<Student> {

}
