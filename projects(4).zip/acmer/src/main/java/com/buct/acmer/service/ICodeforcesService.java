package com.buct.acmer.service;

import com.buct.acmer.entity.Codeforces;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author BUCT
 * @since 2022-06-16
 */
public interface ICodeforcesService extends IService<Codeforces> {

}
