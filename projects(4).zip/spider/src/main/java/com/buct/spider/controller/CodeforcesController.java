package com.buct.spider.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author BUCT
 * @since 2022-06-16
 */
@Controller
@RequestMapping("/spider/codeforces")
public class CodeforcesController {

}
